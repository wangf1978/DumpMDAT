#ifndef _RPC_H_
#define _RPC_H_

#define __RPC_FAR

#define DECLSPEC_UUID(x)
#define MIDL_INTERFACE(x)   struct
#define BEGIN_INTERFACE
#define END_INTERFACE

// From rpcdce.h
typedef void * RPC_IF_HANDLE;


#endif //_RPC_H_
